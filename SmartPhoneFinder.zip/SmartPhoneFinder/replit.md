# PhoneFinder - Smart Phone Recommendations

## Overview

PhoneFinder is a full-stack web application that helps users find the perfect smartphone based on their budget and feature preferences. The application provides personalized recommendations, price comparisons across different sellers, expert reviews, and customer analytics to help users make informed purchasing decisions.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ESM modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **API Pattern**: RESTful API with typed endpoints

### Project Structure
```
├── client/           # Frontend React application
├── server/           # Backend Express API
├── shared/           # Shared types and schemas
├── migrations/       # Database migration files
└── dist/            # Production build output
```

## Key Components

### Database Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Defined in `shared/schema.ts` with four main tables:
  - `phones`: Product information, specs, and ratings
  - `reviews`: YouTube review data and metrics
  - `sellers`: Price comparison data from different retailers
  - `analytics`: Customer satisfaction metrics
- **Migrations**: Managed through Drizzle Kit

### API Endpoints
- `GET /api/phones` - Fetch all phones
- `GET /api/phones/:id` - Get specific phone details
- `GET /api/phones/budget/:budget` - Filter phones by budget
- `POST /api/recommendations` - Get personalized recommendations
- `GET /api/reviews/:phoneId` - Fetch YouTube reviews for a phone
- `GET /api/sellers/:phoneId` - Get price comparison data
- `GET /api/analytics` - Customer satisfaction metrics

### Frontend Components
- **PhoneFinder**: Budget and feature selection interface
- **Recommendations**: Displays personalized phone suggestions
- **ComparisonTable**: Side-by-side specification comparison
- **PriceComparison**: Multi-seller price comparison
- **YoutubeReviews**: Embedded review videos and metrics
- **Analytics**: Customer satisfaction dashboard

### UI Component System
- **Base**: shadcn/ui components with Radix UI primitives
- **Styling**: CSS variables for theming with light/dark mode support
- **Icons**: Font Awesome and Lucide React icons
- **Typography**: Inter font family

## Data Flow

1. **User Input**: Users select budget range and desired features through the PhoneFinder component
2. **Recommendation Engine**: Backend processes criteria and returns matching phones using database queries
3. **Data Enrichment**: Frontend fetches additional data (reviews, sellers, analytics) for recommended phones
4. **Presentation**: Components render personalized recommendations with pricing, reviews, and comparison data
5. **User Action**: Users can compare phones, view detailed reviews, and access purchase links

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI components
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **vite**: Build tool and development server
- **tsx**: TypeScript execution for Node.js
- **esbuild**: Fast JavaScript bundler for production
- **drizzle-kit**: Database migration management

### Third-party Integrations
- **YouTube API**: For fetching review videos and metrics
- **Font Awesome**: Icon library for UI elements
- **Google Fonts**: Inter font family

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR
- **Backend**: tsx for TypeScript execution
- **Database**: Neon Database with connection pooling

### Production Build
- **Frontend**: Vite build to `dist/public`
- **Backend**: esbuild bundle to `dist/index.js`
- **Database**: Drizzle migrations with `db:push` command

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **NODE_ENV**: Environment mode (development/production)
- **REPL_ID**: Replit-specific configuration

### Build Scripts
- `npm run dev`: Start development server
- `npm run build`: Build for production
- `npm run start`: Start production server
- `npm run db:push`: Apply database migrations

## Changelog

Changelog:
- July 26, 2025. Enhanced price comparison with real-time pricing variations across multiple sellers
  - Added realistic price differences between Amazon, Flipkart, brand stores, and other retailers
  - Integrated price alerts system for users to track price drops
  - Enhanced seller data with official stores (Apple Store, Samsung Store, OnePlus Store, etc.)
  - Added price summary dashboard showing lowest/highest prices and maximum savings
  - Improved affiliate marketing links with platform-specific features
- July 08, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.