import { phones, reviews, sellers, analytics, type Phone, type InsertPhone, type Review, type InsertReview, type Seller, type InsertSeller, type Analytics, type InsertAnalytics } from "@shared/schema";

export interface IStorage {
  getPhones(): Promise<Phone[]>;
  getPhoneById(id: number): Promise<Phone | undefined>;
  getPhonesByBudget(budget: number): Promise<Phone[]>;
  getRecommendedPhones(budget: number, features: string[], brand?: string): Promise<Phone[]>;
  getReviewsByPhoneId(phoneId: number): Promise<Review[]>;
  getSellersByPhoneId(phoneId: number): Promise<Seller[]>;
  getAnalyticsByPhoneId(phoneId: number): Promise<Analytics | undefined>;
  createPhone(phone: InsertPhone): Promise<Phone>;
  createReview(review: InsertReview): Promise<Review>;
  createSeller(seller: InsertSeller): Promise<Seller>;
  createAnalytics(analytics: InsertAnalytics): Promise<Analytics>;
}

export class MemStorage implements IStorage {
  private phones: Map<number, Phone> = new Map();
  private reviews: Map<number, Review> = new Map();
  private sellers: Map<number, Seller> = new Map();
  private analytics: Map<number, Analytics> = new Map();
  private currentPhoneId = 1;
  private currentReviewId = 1;
  private currentSellerId = 1;
  private currentAnalyticsId = 1;

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Seed phones data
    const phonesData: InsertPhone[] = [
      {
        name: "Samsung Galaxy S23",
        brand: "samsung",
        price: 74999,
        originalPrice: 89999,
        image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        description: "Perfect for photography enthusiasts with excellent camera system and smooth performance",
        processor: "Snapdragon 8 Gen 2",
        camera: "50MP Triple Camera",
        battery: "3900mAh Battery",
        display: "6.1\" Dynamic AMOLED",
        ram: "8GB",
        storage: "128GB/256GB",
        features: ["camera", "processor", "display", "design"],
        budgetCategory: 60000,
        rating: "4.5",
        reviewCount: 2847,
        pros: ["Excellent camera quality", "Smooth performance", "Premium build"],
        cons: ["Battery could be better", "Expensive"],
        isRecommended: true,
      },
      {
        name: "iPhone 15 Pro",
        brand: "apple",
        price: 134900,
        originalPrice: 134900,
        image: "https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        description: "Ultimate performance with A17 Pro chip and professional camera system",
        processor: "A17 Pro Chip",
        camera: "48MP Pro Camera System",
        battery: "All-day Battery",
        display: "6.1\" Super Retina XDR",
        ram: "8GB",
        storage: "128GB/256GB/512GB/1TB",
        features: ["camera", "processor", "brand", "design"],
        budgetCategory: 100000,
        rating: "4.7",
        reviewCount: 1234,
        pros: ["Best performance", "Premium build", "Excellent cameras"],
        cons: ["Very expensive", "Limited customization"],
        isRecommended: true,
      },
      {
        name: "OnePlus 12",
        brand: "oneplus",
        price: 64999,
        originalPrice: 69999,
        image: "https://images.unsplash.com/photo-1580910051074-3eb694886505?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        description: "Flagship performance with smooth OxygenOS and fast charging",
        processor: "Snapdragon 8 Gen 3",
        camera: "50MP Hasselblad Camera",
        battery: "5400mAh with 100W SuperVOOC",
        display: "6.82\" LTPO OLED",
        ram: "16GB",
        storage: "256GB/512GB",
        features: ["processor", "battery", "smoothness", "camera"],
        budgetCategory: 60000,
        rating: "4.4",
        reviewCount: 892,
        pros: ["Fast charging", "Smooth UI", "Great value"],
        cons: ["Camera could be better", "Build quality"],
        isRecommended: false,
      },
      {
        name: "Redmi Note 13",
        brand: "xiaomi",
        price: 13999,
        originalPrice: 15999,
        image: "https://images.unsplash.com/photo-1565849904461-04a58ad377e0?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        description: "Best budget phone with good camera and performance",
        processor: "Snapdragon 685",
        camera: "108MP Triple Camera",
        battery: "5000mAh",
        display: "6.67\" AMOLED",
        ram: "6GB",
        storage: "128GB",
        features: ["camera", "battery", "display"],
        budgetCategory: 15000,
        rating: "4.2",
        reviewCount: 5621,
        pros: ["Great value", "Good camera", "Long battery life"],
        cons: ["Performance could be better", "Build quality"],
        isRecommended: true,
      },
      {
        name: "Realme GT Neo 6",
        brand: "realme",
        price: 28999,
        originalPrice: 32999,
        image: "https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        description: "Gaming focused phone with excellent performance",
        processor: "Snapdragon 7+ Gen 3",
        camera: "50MP OIS Camera",
        battery: "5000mAh with 120W",
        display: "6.78\" 120Hz OLED",
        ram: "8GB",
        storage: "256GB",
        features: ["processor", "battery", "smoothness", "camera"],
        budgetCategory: 30000,
        rating: "4.3",
        reviewCount: 1876,
        pros: ["Gaming performance", "Fast charging", "Good display"],
        cons: ["Camera could be better", "Heating issues"],
        isRecommended: false,
      },
      {
        name: "Google Pixel 8",
        brand: "google",
        price: 58999,
        originalPrice: 75999,
        image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        description: "Pure Android experience with excellent AI features",
        processor: "Google Tensor G3",
        camera: "50MP Dual Camera",
        battery: "4575mAh",
        display: "6.2\" OLED",
        ram: "8GB",
        storage: "128GB/256GB",
        features: ["camera", "processor", "brand", "design"],
        budgetCategory: 60000,
        rating: "4.6",
        reviewCount: 934,
        pros: ["Clean Android", "Excellent cameras", "AI features"],
        cons: ["Battery life", "Limited availability"],
        isRecommended: true,
      },
      {
        name: "iPhone 15 Pro Max",
        brand: "apple",
        price: 159900,
        originalPrice: 159900,
        image: "https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        description: "Ultimate iPhone with largest display and best cameras",
        processor: "A17 Pro Chip",
        camera: "48MP Pro Camera System",
        battery: "Longest battery life",
        display: "6.7\" Super Retina XDR",
        ram: "8GB",
        storage: "256GB/512GB/1TB",
        features: ["camera", "processor", "brand", "design", "display"],
        budgetCategory: 100000,
        rating: "4.8",
        reviewCount: 567,
        pros: ["Best performance", "Excellent cameras", "Premium build"],
        cons: ["Very expensive", "Heavy"],
        isRecommended: true,
      },
    ];

    phonesData.forEach(phone => {
      this.createPhone(phone);
    });

    // Seed reviews data
    const reviewsData: InsertReview[] = [
      {
        phoneId: 1,
        channel: "Technical Guruji",
        title: "Samsung Galaxy S23 Complete Review - Worth Buying?",
        videoId: "dQw4w9WgXcQ",
        thumbnail: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
        views: "2.3M",
        likePercentage: 95,
      },
      {
        phoneId: 2,
        channel: "Geeky Ranjit",
        title: "iPhone 15 Pro vs Samsung Galaxy S23 - Which to Buy?",
        videoId: "dQw4w9WgXcQ",
        thumbnail: "https://pixabay.com/get/g6b3796e8b8626b1bdc30ba7f324786e444f97e2a3cad5ef053d04b450fc2a7d2add0858b5cb5685cab968c13434e4ff75725b49c32e2319e3fe893fa8acaa6d8_1280.jpg",
        views: "1.8M",
        likePercentage: 92,
      },
      {
        phoneId: 3,
        channel: "Trakin Tech",
        title: "OnePlus 12 Full Review - Gaming Beast at Best Price!",
        videoId: "dQw4w9WgXcQ",
        thumbnail: "https://pixabay.com/get/g68928c1afa085b2583daebf3153b865d09ae7be5d4dce0fb6cf977fdc4a63dbe3fb59b9fbc6a23c1a448955ffc52db9a245f3b3fc55599f3a14b24e0dbe0ce91_1280.jpg",
        views: "956K",
        likePercentage: 96,
      },
    ];

    reviewsData.forEach(review => {
      this.createReview(review);
    });

    // Seed sellers data with realistic price variations
    const sellersData: InsertSeller[] = [
      // Samsung Galaxy S23 sellers
      {
        phoneId: 1,
        name: "Amazon",
        icon: "amazon",
        color: "orange",
        price: 74999,
        originalPrice: 89999,
        discount: 17,
        affiliateLink: "https://amazon.in/samsung-galaxy-s23",
        features: ["Prime eligible", "Fast delivery"],
      },
      {
        phoneId: 1,
        name: "Flipkart",
        icon: "shopping-cart",
        color: "blue",
        price: 73999,
        originalPrice: 89999,
        discount: 18,
        affiliateLink: "https://flipkart.com/samsung-galaxy-s23",
        features: ["Plus member", "Exchange offer"],
      },
      {
        phoneId: 1,
        name: "Samsung Store",
        icon: "store",
        color: "black",
        price: 79999,
        originalPrice: 89999,
        discount: 11,
        affiliateLink: "https://samsung.com/in/galaxy-s23",
        features: ["Official warranty", "Trade-in"],
      },
      {
        phoneId: 1,
        name: "Croma",
        icon: "store",
        color: "purple",
        price: 75999,
        originalPrice: 89999,
        discount: 16,
        affiliateLink: "https://croma.com/samsung-galaxy-s23",
        features: ["Store pickup", "EMI"],
      },
      
      // iPhone 15 Pro sellers
      {
        phoneId: 2,
        name: "Amazon",
        icon: "amazon",
        color: "orange",
        price: 132999,
        originalPrice: 134900,
        discount: 1,
        affiliateLink: "https://amazon.in/iphone-15-pro",
        features: ["Prime eligible"],
      },
      {
        phoneId: 2,
        name: "Flipkart",
        icon: "shopping-cart",
        color: "blue",
        price: 129999,
        originalPrice: 134900,
        discount: 4,
        affiliateLink: "https://flipkart.com/iphone-15-pro",
        features: ["Plus member", "Exchange"],
      },
      {
        phoneId: 2,
        name: "Apple Store",
        icon: "apple",
        color: "gray",
        price: 134900,
        originalPrice: 134900,
        discount: 0,
        affiliateLink: "https://apple.com/in/iphone-15-pro",
        features: ["Official", "AppleCare"],
      },
      {
        phoneId: 2,
        name: "Vijay Sales",
        icon: "store",
        color: "red",
        price: 131999,
        originalPrice: 134900,
        discount: 2,
        affiliateLink: "https://vijaysales.com/iphone-15-pro",
        features: ["Store pickup"],
      },
      
      // OnePlus 12 sellers
      {
        phoneId: 3,
        name: "Amazon",
        icon: "amazon",
        color: "orange",
        price: 64999,
        originalPrice: 69999,
        discount: 7,
        affiliateLink: "https://amazon.in/oneplus-12",
        features: ["Prime eligible"],
      },
      {
        phoneId: 3,
        name: "OnePlus Store",
        icon: "mobile-alt",
        color: "red",
        price: 67999,
        originalPrice: 69999,
        discount: 3,
        affiliateLink: "https://oneplus.in/12",
        features: ["Official", "Extended warranty"],
      },
      {
        phoneId: 3,
        name: "Flipkart",
        icon: "shopping-cart",
        color: "blue",
        price: 63999,
        originalPrice: 69999,
        discount: 9,
        affiliateLink: "https://flipkart.com/oneplus-12",
        features: ["Plus member", "Exchange"],
      },
      
      // Redmi Note 13 sellers
      {
        phoneId: 4,
        name: "Amazon",
        icon: "amazon",
        color: "orange",
        price: 13999,
        originalPrice: 15999,
        discount: 13,
        affiliateLink: "https://amazon.in/redmi-note-13",
        features: ["Prime eligible"],
      },
      {
        phoneId: 4,
        name: "Flipkart",
        icon: "shopping-cart",
        color: "blue",
        price: 13499,
        originalPrice: 15999,
        discount: 16,
        affiliateLink: "https://flipkart.com/redmi-note-13",
        features: ["Plus member"],
      },
      {
        phoneId: 4,
        name: "Mi Store",
        icon: "store",
        color: "orange",
        price: 14999,
        originalPrice: 15999,
        discount: 6,
        affiliateLink: "https://mi.com/in/redmi-note-13",
        features: ["Official", "Mi Care"],
      },
      
      // Realme GT Neo 6 sellers
      {
        phoneId: 5,
        name: "Amazon",
        icon: "amazon",
        color: "orange",
        price: 28999,
        originalPrice: 32999,
        discount: 12,
        affiliateLink: "https://amazon.in/realme-gt-neo-6",
        features: ["Prime eligible"],
      },
      {
        phoneId: 5,
        name: "Realme Store",
        icon: "mobile-alt",
        color: "yellow",
        price: 31999,
        originalPrice: 32999,
        discount: 3,
        affiliateLink: "https://realme.com/in/gt-neo-6",
        features: ["Official", "Extended warranty"],
      },
      {
        phoneId: 5,
        name: "Flipkart",
        icon: "shopping-cart",
        color: "blue",
        price: 27999,
        originalPrice: 32999,
        discount: 15,
        affiliateLink: "https://flipkart.com/realme-gt-neo-6",
        features: ["Plus member"],
      },
      
      // Google Pixel 8 sellers
      {
        phoneId: 6,
        name: "Amazon",
        icon: "amazon",
        color: "orange",
        price: 58999,
        originalPrice: 75999,
        discount: 22,
        affiliateLink: "https://amazon.in/google-pixel-8",
        features: ["Prime eligible"],
      },
      {
        phoneId: 6,
        name: "Flipkart",
        icon: "shopping-cart",
        color: "blue",
        price: 56999,
        originalPrice: 75999,
        discount: 25,
        affiliateLink: "https://flipkart.com/google-pixel-8",
        features: ["Plus member", "Exchange"],
      },
      {
        phoneId: 6,
        name: "Google Store",
        icon: "google",
        color: "blue",
        price: 62999,
        originalPrice: 75999,
        discount: 17,
        affiliateLink: "https://store.google.com/pixel-8",
        features: ["Official", "Pixel Pass"],
      },
      
      // iPhone 15 Pro Max sellers
      {
        phoneId: 7,
        name: "Amazon",
        icon: "amazon",
        color: "orange",
        price: 157999,
        originalPrice: 159900,
        discount: 1,
        affiliateLink: "https://amazon.in/iphone-15-pro-max",
        features: ["Prime eligible"],
      },
      {
        phoneId: 7,
        name: "Flipkart",
        icon: "shopping-cart",
        color: "blue",
        price: 154999,
        originalPrice: 159900,
        discount: 3,
        affiliateLink: "https://flipkart.com/iphone-15-pro-max",
        features: ["Plus member", "Exchange"],
      },
      {
        phoneId: 7,
        name: "Apple Store",
        icon: "apple",
        color: "gray",
        price: 159900,
        originalPrice: 159900,
        discount: 0,
        affiliateLink: "https://apple.com/in/iphone-15-pro-max",
        features: ["Official", "AppleCare"],
      },
      {
        phoneId: 7,
        name: "Croma",
        icon: "store",
        color: "purple",
        price: 156999,
        originalPrice: 159900,
        discount: 2,
        affiliateLink: "https://croma.com/iphone-15-pro-max",
        features: ["Store pickup", "EMI"],
      },
    ];

    sellersData.forEach(seller => {
      this.createSeller(seller);
    });

    // Seed analytics data
    const analyticsData: InsertAnalytics[] = [
      {
        phoneId: 1,
        satisfactionPercentage: 92,
        totalReviews: 15000,
        averageRating: "4.6",
        recommendationAccuracy: 89,
      },
      {
        phoneId: 2,
        satisfactionPercentage: 96,
        totalReviews: 8500,
        averageRating: "4.7",
        recommendationAccuracy: 94,
      },
      {
        phoneId: 3,
        satisfactionPercentage: 89,
        totalReviews: 12000,
        averageRating: "4.4",
        recommendationAccuracy: 87,
      },
    ];

    analyticsData.forEach(analytics => {
      this.createAnalytics(analytics);
    });
  }

  async getPhones(): Promise<Phone[]> {
    return Array.from(this.phones.values());
  }

  async getPhoneById(id: number): Promise<Phone | undefined> {
    return this.phones.get(id);
  }

  async getPhonesByBudget(budget: number): Promise<Phone[]> {
    return Array.from(this.phones.values()).filter(phone => {
      if (budget === 100000) {
        return phone.price >= 100000;
      }
      return phone.budgetCategory <= budget;
    });
  }

  async getRecommendedPhones(budget: number, features: string[], brand?: string): Promise<Phone[]> {
    const budgetPhones = await this.getPhonesByBudget(budget);
    
    return budgetPhones
      .filter(phone => {
        if (brand && brand !== "no_preference" && phone.brand !== brand) return false;
        
        // Check if phone has matching features
        const matchingFeatures = features.filter(feature => 
          phone.features.includes(feature)
        );
        
        return matchingFeatures.length > 0;
      })
      .sort((a, b) => {
        // Sort by feature matches, then by rating
        const aMatches = features.filter(f => a.features.includes(f)).length;
        const bMatches = features.filter(f => b.features.includes(f)).length;
        
        if (aMatches !== bMatches) {
          return bMatches - aMatches;
        }
        
        return parseFloat(b.rating) - parseFloat(a.rating);
      })
      .slice(0, 6);
  }

  async getReviewsByPhoneId(phoneId: number): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(review => review.phoneId === phoneId);
  }

  async getSellersByPhoneId(phoneId: number): Promise<Seller[]> {
    return Array.from(this.sellers.values()).filter(seller => seller.phoneId === phoneId);
  }

  async getAnalyticsByPhoneId(phoneId: number): Promise<Analytics | undefined> {
    return Array.from(this.analytics.values()).find(analytics => analytics.phoneId === phoneId);
  }

  async createPhone(insertPhone: InsertPhone): Promise<Phone> {
    const id = this.currentPhoneId++;
    const phone: Phone = {
      ...insertPhone,
      id,
      originalPrice: insertPhone.originalPrice || null,
      createdAt: new Date(),
    };
    this.phones.set(id, phone);
    return phone;
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.currentReviewId++;
    const review: Review = {
      ...insertReview,
      id,
      phoneId: insertReview.phoneId || null,
      createdAt: new Date(),
    };
    this.reviews.set(id, review);
    return review;
  }

  async createSeller(insertSeller: InsertSeller): Promise<Seller> {
    const id = this.currentSellerId++;
    const seller: Seller = {
      ...insertSeller,
      id,
      phoneId: insertSeller.phoneId || null,
      originalPrice: insertSeller.originalPrice || null,
      discount: insertSeller.discount || null,
      features: insertSeller.features || null,
      createdAt: new Date(),
    };
    this.sellers.set(id, seller);
    return seller;
  }

  async createAnalytics(insertAnalytics: InsertAnalytics): Promise<Analytics> {
    const id = this.currentAnalyticsId++;
    const analytics: Analytics = {
      ...insertAnalytics,
      id,
      phoneId: insertAnalytics.phoneId || null,
      createdAt: new Date(),
    };
    this.analytics.set(id, analytics);
    return analytics;
  }
}

export const storage = new MemStorage();
