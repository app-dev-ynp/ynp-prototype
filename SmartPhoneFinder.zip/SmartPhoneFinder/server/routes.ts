import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

const recommendationSchema = z.object({
  budget: z.number().min(1000),
  features: z.array(z.string()),
  brand: z.string().optional(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all phones
  app.get("/api/phones", async (req, res) => {
    try {
      const phones = await storage.getPhones();
      res.json(phones);
    } catch (error) {
      console.error("Error fetching phones:", error);
      res.status(500).json({ error: "Failed to fetch phones" });
    }
  });

  // Get phone by ID
  app.get("/api/phones/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const phone = await storage.getPhoneById(id);
      
      if (!phone) {
        return res.status(404).json({ error: "Phone not found" });
      }
      
      res.json(phone);
    } catch (error) {
      console.error("Error fetching phone:", error);
      res.status(500).json({ error: "Failed to fetch phone" });
    }
  });

  // Get phones by budget
  app.get("/api/phones/budget/:budget", async (req, res) => {
    try {
      const budget = parseInt(req.params.budget);
      const phones = await storage.getPhonesByBudget(budget);
      res.json(phones);
    } catch (error) {
      console.error("Error fetching phones by budget:", error);
      res.status(500).json({ error: "Failed to fetch phones by budget" });
    }
  });

  // Get recommendations
  app.post("/api/recommendations", async (req, res) => {
    try {
      const { budget, features, brand } = recommendationSchema.parse(req.body);
      const recommendations = await storage.getRecommendedPhones(budget, features, brand);
      res.json(recommendations);
    } catch (error) {
      console.error("Error getting recommendations:", error);
      res.status(500).json({ error: "Failed to get recommendations" });
    }
  });

  // Get reviews by phone ID
  app.get("/api/reviews/:phoneId", async (req, res) => {
    try {
      const phoneId = parseInt(req.params.phoneId);
      const reviews = await storage.getReviewsByPhoneId(phoneId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ error: "Failed to fetch reviews" });
    }
  });

  // Get sellers by phone ID
  app.get("/api/sellers/:phoneId", async (req, res) => {
    try {
      const phoneId = parseInt(req.params.phoneId);
      const sellers = await storage.getSellersByPhoneId(phoneId);
      res.json(sellers);
    } catch (error) {
      console.error("Error fetching sellers:", error);
      res.status(500).json({ error: "Failed to fetch sellers" });
    }
  });

  // Get analytics by phone ID
  app.get("/api/analytics/:phoneId", async (req, res) => {
    try {
      const phoneId = parseInt(req.params.phoneId);
      const analytics = await storage.getAnalyticsByPhoneId(phoneId);
      
      if (!analytics) {
        return res.status(404).json({ error: "Analytics not found" });
      }
      
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching analytics:", error);
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  // Get overall analytics
  app.get("/api/analytics", async (req, res) => {
    try {
      const phones = await storage.getPhones();
      const totalReviews = phones.reduce((sum, phone) => sum + phone.reviewCount, 0);
      const avgRating = phones.reduce((sum, phone) => sum + parseFloat(phone.rating), 0) / phones.length;
      const avgSatisfaction = 94; // Mock overall satisfaction
      
      const overallAnalytics = {
        totalReviews,
        averageRating: avgRating.toFixed(1),
        overallSatisfaction: avgSatisfaction,
        recommendationAccuracy: 89,
      };
      
      res.json(overallAnalytics);
    } catch (error) {
      console.error("Error fetching overall analytics:", error);
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
