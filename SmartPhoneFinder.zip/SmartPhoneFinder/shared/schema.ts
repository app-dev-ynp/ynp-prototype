import { pgTable, text, serial, integer, boolean, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const phones = pgTable("phones", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  brand: text("brand").notNull(),
  price: integer("price").notNull(),
  originalPrice: integer("original_price"),
  image: text("image").notNull(),
  description: text("description").notNull(),
  processor: text("processor").notNull(),
  camera: text("camera").notNull(),
  battery: text("battery").notNull(),
  display: text("display").notNull(),
  ram: text("ram").notNull(),
  storage: text("storage").notNull(),
  features: text("features").array().notNull(),
  budgetCategory: integer("budget_category").notNull(),
  rating: decimal("rating", { precision: 2, scale: 1 }).notNull(),
  reviewCount: integer("review_count").notNull(),
  pros: text("pros").array().notNull(),
  cons: text("cons").array().notNull(),
  isRecommended: boolean("is_recommended").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  phoneId: integer("phone_id").references(() => phones.id),
  channel: text("channel").notNull(),
  title: text("title").notNull(),
  videoId: text("video_id").notNull(),
  thumbnail: text("thumbnail").notNull(),
  views: text("views").notNull(),
  likePercentage: integer("like_percentage").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sellers = pgTable("sellers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
  phoneId: integer("phone_id").references(() => phones.id),
  price: integer("price").notNull(),
  originalPrice: integer("original_price"),
  discount: integer("discount"),
  affiliateLink: text("affiliate_link").notNull(),
  features: text("features").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const analytics = pgTable("analytics", {
  id: serial("id").primaryKey(),
  phoneId: integer("phone_id").references(() => phones.id),
  satisfactionPercentage: integer("satisfaction_percentage").notNull(),
  totalReviews: integer("total_reviews").notNull(),
  averageRating: decimal("average_rating", { precision: 2, scale: 1 }).notNull(),
  recommendationAccuracy: integer("recommendation_accuracy").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPhoneSchema = createInsertSchema(phones).omit({
  id: true,
  createdAt: true,
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  createdAt: true,
});

export const insertSellerSchema = createInsertSchema(sellers).omit({
  id: true,
  createdAt: true,
});

export const insertAnalyticsSchema = createInsertSchema(analytics).omit({
  id: true,
  createdAt: true,
});

export type Phone = typeof phones.$inferSelect;
export type InsertPhone = z.infer<typeof insertPhoneSchema>;
export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Seller = typeof sellers.$inferSelect;
export type InsertSeller = z.infer<typeof insertSellerSchema>;
export type Analytics = typeof analytics.$inferSelect;
export type InsertAnalytics = z.infer<typeof insertAnalyticsSchema>;

export const budgetCategories = [
  { value: 5000, label: "₹5,000", description: "Budget Basic" },
  { value: 10000, label: "₹10,000", description: "Entry Level" },
  { value: 15000, label: "₹15,000", description: "Mid-Range" },
  { value: 20000, label: "₹20,000", description: "Premium" },
  { value: 30000, label: "₹30,000", description: "High-End" },
  { value: 50000, label: "₹50,000", description: "Flagship" },
  { value: 60000, label: "₹60,000", description: "Ultra Premium" },
  { value: 100000, label: "₹1,00,000+", description: "Luxury" },
];

export const phoneFeatures = [
  { value: "camera", label: "Camera", icon: "camera" },
  { value: "battery", label: "Battery Life", icon: "battery-full" },
  { value: "processor", label: "Processor", icon: "microchip" },
  { value: "display", label: "Display", icon: "desktop" },
  { value: "brand", label: "Brand", icon: "star" },
  { value: "multicam", label: "Multiple Cameras", icon: "photo-video" },
  { value: "smoothness", label: "Smoothness", icon: "tachometer-alt" },
  { value: "design", label: "Design", icon: "paint-brush" },
];

export const phoneBrands = [
  { value: "no_preference", label: "No Preference" },
  { value: "apple", label: "Apple" },
  { value: "samsung", label: "Samsung" },
  { value: "oneplus", label: "OnePlus" },
  { value: "xiaomi", label: "Xiaomi" },
  { value: "realme", label: "Realme" },
  { value: "oppo", label: "Oppo" },
  { value: "vivo", label: "Vivo" },
  { value: "google", label: "Google" },
  { value: "nothing", label: "Nothing" },
  { value: "motorola", label: "Motorola" },
  { value: "honor", label: "Honor" },
  { value: "iqoo", label: "iQOO" },
];
