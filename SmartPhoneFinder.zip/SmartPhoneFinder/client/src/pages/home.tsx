import Header from "@/components/header";
import PhoneFinder from "@/components/phone-finder";
import Recommendations from "@/components/recommendations";
import ComparisonTable from "@/components/comparison-table";
import Analytics from "@/components/analytics";
import YoutubeReviews from "@/components/youtube-reviews";
import PriceComparison from "@/components/price-comparison";
import Footer from "@/components/footer";
import { useState } from "react";
import { Phone } from "@shared/schema";

export default function Home() {
  const [selectedBudget, setSelectedBudget] = useState<number | null>(null);
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);
  const [selectedBrand, setSelectedBrand] = useState<string>("no_preference");
  const [recommendations, setRecommendations] = useState<Phone[]>([]);
  const [showRecommendations, setShowRecommendations] = useState(false);

  const handleGetRecommendations = () => {
    if (selectedBudget && selectedFeatures.length > 0) {
      setShowRecommendations(true);
    }
  };

  const handleRecommendationsUpdate = (phones: Phone[]) => {
    setRecommendations(phones);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Find Your Perfect Phone</h2>
          <p className="text-xl md:text-2xl mb-8 opacity-90">Smart recommendations based on your budget and features</p>
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 flex items-center">
              <i className="fas fa-search text-2xl mr-3"></i>
              <span className="text-lg">Smart Search</span>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 flex items-center">
              <i className="fas fa-chart-line text-2xl mr-3"></i>
              <span className="text-lg">Price Comparison</span>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 flex items-center">
              <i className="fas fa-star text-2xl mr-3"></i>
              <span className="text-lg">Expert Reviews</span>
            </div>
          </div>
          <button 
            onClick={() => document.getElementById('phone-finder')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-white text-primary px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
          >
            Start Finding Now
          </button>
        </div>
      </section>

      <div id="phone-finder">
        <PhoneFinder
          selectedBudget={selectedBudget}
          selectedFeatures={selectedFeatures}
          selectedBrand={selectedBrand}
          onBudgetChange={setSelectedBudget}
          onFeaturesChange={setSelectedFeatures}
          onBrandChange={setSelectedBrand}
          onGetRecommendations={handleGetRecommendations}
        />
      </div>

      {showRecommendations && (
        <>
          <Recommendations
            budget={selectedBudget}
            features={selectedFeatures}
            brand={selectedBrand}
            onRecommendationsUpdate={handleRecommendationsUpdate}
          />
          
          {recommendations.length > 0 && (
            <>
              <ComparisonTable phones={recommendations.slice(0, 3)} />
              <Analytics />
              <YoutubeReviews phones={recommendations.slice(0, 3)} />
              
              {/* Price Comparison for Top 3 Recommendations */}
              {recommendations.slice(0, 3).map((phone, index) => (
                <div key={phone.id} id={`price-comparison-${phone.id}`}>
                  <PriceComparison phone={phone} />
                </div>
              ))}
            </>
          )}
        </>
      )}

      <Footer />
    </div>
  );
}
