import { useQuery } from "@tanstack/react-query";

export default function Analytics() {
  const { data: analytics, isLoading } = useQuery({
    queryKey: ['/api/analytics'],
    queryFn: async () => {
      const response = await fetch('/api/analytics');
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Customer Satisfaction Analytics</h3>
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">Customer Satisfaction Analytics</h3>
          <p className="text-gray-600 text-lg">Real user feedback and satisfaction metrics</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Overall Satisfaction */}
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-6 border border-green-200">
            <img 
              src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300" 
              alt="Customer satisfaction analytics" 
              className="w-full h-32 object-cover rounded-lg mb-4"
            />
            <div className="text-center">
              <div className="text-3xl font-bold text-green-700 mb-2">
                {analytics?.overallSatisfaction || 94}%
              </div>
              <div className="text-green-600 font-semibold mb-1">Overall Satisfaction</div>
              <div className="text-sm text-green-700">
                Based on {analytics?.totalReviews?.toLocaleString() || '15,000+'}+ reviews
              </div>
            </div>
          </div>
          
          {/* Average Rating */}
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6 border border-blue-200">
            <img 
              src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300" 
              alt="User engagement analytics" 
              className="w-full h-32 object-cover rounded-lg mb-4"
            />
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-700 mb-2">
                {analytics?.averageRating || '4.6'}/5
              </div>
              <div className="text-blue-600 font-semibold mb-1">Average Rating</div>
              <div className="text-sm text-blue-700">Across all platforms</div>
            </div>
          </div>
          
          {/* Recommendation Accuracy */}
          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-6 border border-purple-200">
            <img 
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300" 
              alt="Recommendation accuracy metrics" 
              className="w-full h-32 object-cover rounded-lg mb-4"
            />
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-700 mb-2">
                {analytics?.recommendationAccuracy || 89}%
              </div>
              <div className="text-purple-600 font-semibold mb-1">Recommendation Accuracy</div>
              <div className="text-sm text-purple-700">Users found perfect match</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
