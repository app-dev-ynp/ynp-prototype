import { useState } from "react";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <i className="fas fa-mobile-alt text-2xl text-primary mr-3"></i>
            <h1 className="text-2xl font-bold text-gray-900">PhoneFinder</h1>
          </div>
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-gray-700 hover:text-primary transition-colors">Home</a>
            <a href="#" className="text-gray-700 hover:text-primary transition-colors">Compare</a>
            <a href="#" className="text-gray-700 hover:text-primary transition-colors">Reviews</a>
            <a href="#" className="text-gray-700 hover:text-primary transition-colors">Deals</a>
          </nav>
          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <i className="fas fa-bars text-gray-700"></i>
          </button>
        </div>
        
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <nav className="flex flex-col space-y-2">
              <a href="#" className="text-gray-700 hover:text-primary transition-colors py-2">Home</a>
              <a href="#" className="text-gray-700 hover:text-primary transition-colors py-2">Compare</a>
              <a href="#" className="text-gray-700 hover:text-primary transition-colors py-2">Reviews</a>
              <a href="#" className="text-gray-700 hover:text-primary transition-colors py-2">Deals</a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
