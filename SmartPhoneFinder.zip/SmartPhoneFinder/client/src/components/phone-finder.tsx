import { budgetCategories, phoneFeatures, phoneBrands } from "@shared/schema";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface PhoneFinderProps {
  selectedBudget: number | null;
  selectedFeatures: string[];
  selectedBrand: string;
  onBudgetChange: (budget: number) => void;
  onFeaturesChange: (features: string[]) => void;
  onBrandChange: (brand: string) => void;
  onGetRecommendations: () => void;
}

export default function PhoneFinder({
  selectedBudget,
  selectedFeatures,
  selectedBrand,
  onBudgetChange,
  onFeaturesChange,
  onBrandChange,
  onGetRecommendations,
}: PhoneFinderProps) {
  const handleBudgetSelect = (budget: number) => {
    onBudgetChange(budget);
  };

  const handleFeatureToggle = (feature: string) => {
    if (selectedFeatures.includes(feature)) {
      onFeaturesChange(selectedFeatures.filter(f => f !== feature));
    } else {
      onFeaturesChange([...selectedFeatures, feature]);
    }
  };

  const getGradientClass = (index: number) => {
    const gradients = [
      "from-green-50 to-green-100 hover:border-green-300",
      "from-blue-50 to-blue-100 hover:border-blue-300",
      "from-purple-50 to-purple-100 hover:border-purple-300",
      "from-orange-50 to-orange-100 hover:border-orange-300",
      "from-red-50 to-red-100 hover:border-red-300",
      "from-indigo-50 to-indigo-100 hover:border-indigo-300",
      "from-pink-50 to-pink-100 hover:border-pink-300",
      "from-gray-50 to-gray-100 hover:border-gray-300",
    ];
    return gradients[index % gradients.length];
  };

  const getTextColor = (index: number) => {
    const colors = [
      "text-green-700",
      "text-blue-700",
      "text-purple-700",
      "text-orange-700",
      "text-red-700",
      "text-indigo-700",
      "text-pink-700",
      "text-gray-700",
    ];
    return colors[index % colors.length];
  };

  const getDescriptionColor = (index: number) => {
    const colors = [
      "text-green-600",
      "text-blue-600",
      "text-purple-600",
      "text-orange-600",
      "text-red-600",
      "text-indigo-600",
      "text-pink-600",
      "text-gray-600",
    ];
    return colors[index % colors.length];
  };

  return (
    <>
      {/* Budget Selection */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Step 1: Choose Your Budget</h3>
            <p className="text-gray-600 text-lg">Select your preferred price range</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {budgetCategories.map((category, index) => (
              <div
                key={category.value}
                className={`budget-card bg-gradient-to-br ${getGradientClass(index)} p-6 rounded-xl border-2 cursor-pointer transition-all duration-200 ${
                  selectedBudget === category.value ? 'border-primary ring-2 ring-primary' : 'border-transparent'
                }`}
                onClick={() => handleBudgetSelect(category.value)}
              >
                <div className="text-center">
                  <div className={`text-2xl font-bold ${getTextColor(index)} mb-2`}>{category.label}</div>
                  <div className={`text-sm ${getDescriptionColor(index)}`}>{category.description}</div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center">
            <div className="inline-flex items-center px-4 py-2 bg-blue-50 rounded-full">
              <i className="fas fa-info-circle text-blue-600 mr-2"></i>
              <span className="text-blue-800 text-sm">
                Selected Budget: <span className="font-semibold">
                  {selectedBudget ? budgetCategories.find(c => c.value === selectedBudget)?.label : 'Not Selected'}
                </span>
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Selection */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Step 2: Select Important Features</h3>
            <p className="text-gray-600 text-lg">Choose the features that matter most to you</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {phoneFeatures.map((feature) => (
              <div
                key={feature.value}
                className={`feature-card bg-white p-6 rounded-xl shadow-sm border-2 cursor-pointer transition-all duration-200 ${
                  selectedFeatures.includes(feature.value) 
                    ? 'border-primary ring-2 ring-primary bg-blue-50' 
                    : 'border-gray-200 hover:border-primary hover:shadow-md'
                }`}
                onClick={() => handleFeatureToggle(feature.value)}
              >
                <div className="text-center">
                  <i className={`fas fa-${feature.icon} text-3xl text-gray-600 mb-3`}></i>
                  <div className="font-semibold text-gray-900">{feature.label}</div>
                  <div className="text-sm text-gray-600 mt-1">
                    {feature.value === 'camera' && 'Photo & Video Quality'}
                    {feature.value === 'battery' && 'Size & Performance'}
                    {feature.value === 'processor' && 'Performance & Speed'}
                    {feature.value === 'display' && 'Size & Quality'}
                    {feature.value === 'brand' && 'Trust & Reliability'}
                    {feature.value === 'multicam' && 'Versatile Photography'}
                    {feature.value === 'smoothness' && 'Refresh Rate & UI'}
                    {feature.value === 'design' && 'Look & Feel'}
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mb-8">
            <div className="inline-flex items-center px-4 py-2 bg-green-50 rounded-full">
              <i className="fas fa-check-circle text-green-600 mr-2"></i>
              <span className="text-green-800 text-sm">
                Selected Features: <span className="font-semibold">
                  {selectedFeatures.length > 0 ? selectedFeatures.map(f => 
                    phoneFeatures.find(feature => feature.value === f)?.label
                  ).join(', ') : 'None'}
                </span>
              </span>
            </div>
          </div>
          
          {/* Brand Preference */}
          <div className="max-w-2xl mx-auto mb-8">
            <label className="block text-sm font-medium text-gray-700 mb-2">Brand Preference (Optional)</label>
            <Select value={selectedBrand || "no_preference"} onValueChange={onBrandChange}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select a brand" />
              </SelectTrigger>
              <SelectContent>
                {phoneBrands.map((brand) => (
                  <SelectItem key={brand.value} value={brand.value}>
                    {brand.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="text-center">
            <button 
              onClick={onGetRecommendations}
              disabled={!selectedBudget || selectedFeatures.length === 0}
              className="bg-primary text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Get Recommendations
            </button>
          </div>
        </div>
      </section>
    </>
  );
}
