import { useQuery } from "@tanstack/react-query";
import { Phone } from "@shared/schema";
import { useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";

interface RecommendationsProps {
  budget: number | null;
  features: string[];
  brand: string;
  onRecommendationsUpdate: (phones: Phone[]) => void;
}

export default function Recommendations({ budget, features, brand, onRecommendationsUpdate }: RecommendationsProps) {
  const { data: phones, isLoading, error } = useQuery({
    queryKey: ['/api/recommendations', budget, features, brand],
    queryFn: async () => {
      const response = await apiRequest('POST', '/api/recommendations', {
        budget,
        features,
        brand: brand === "no_preference" ? undefined : brand,
      });
      return response.json();
    },
    enabled: !!budget && features.length > 0,
  });

  useEffect(() => {
    if (phones) {
      onRecommendationsUpdate(phones);
    }
  }, [phones, onRecommendationsUpdate]);

  if (isLoading) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Finding Perfect Matches...</h3>
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Something went wrong</h3>
            <p className="text-gray-600">Please try again later</p>
          </div>
        </div>
      </section>
    );
  }

  if (!phones || phones.length === 0) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">No Perfect Matches Found</h3>
            <p className="text-gray-600">Try adjusting your budget or feature preferences</p>
          </div>
        </div>
      </section>
    );
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getBadgeColor = (index: number) => {
    const colors = ["bg-green-500", "bg-purple-500", "bg-blue-500", "bg-orange-500", "bg-red-500", "bg-indigo-500"];
    return colors[index % colors.length];
  };

  const getBadgeText = (index: number) => {
    const badges = ["Best Match", "Premium", "Value Pick", "Popular", "Recommended", "Top Rated"];
    return badges[index % badges.length];
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">Perfect Matches for You</h3>
          <p className="text-gray-600 text-lg">Based on your budget and feature preferences</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {phones.map((phone: Phone, index: number) => (
            <div key={phone.id} className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200 hover:shadow-xl transition-shadow duration-300">
              <div className="relative">
                <img 
                  src={phone.image} 
                  alt={phone.name} 
                  className="w-full h-48 object-cover"
                />
                <div className={`absolute top-4 right-4 ${getBadgeColor(index)} text-white px-3 py-1 rounded-full text-sm font-semibold`}>
                  {getBadgeText(index)}
                </div>
              </div>
              <div className="p-6">
                <h4 className="text-xl font-bold text-gray-900 mb-2">{phone.name}</h4>
                <p className="text-gray-600 mb-4">{phone.description}</p>
                
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">Customer Satisfaction</span>
                    <span className="text-sm font-semibold text-green-600">
                      {Math.round(parseFloat(phone.rating) * 20)}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full" 
                      style={{ width: `${Math.round(parseFloat(phone.rating) * 20)}%` }}
                    ></div>
                  </div>
                </div>
                
                <div className="space-y-2 mb-4">
                  <div className="flex items-center">
                    <i className="fas fa-camera text-primary mr-2"></i>
                    <span className="text-sm">{phone.camera}</span>
                  </div>
                  <div className="flex items-center">
                    <i className="fas fa-microchip text-primary mr-2"></i>
                    <span className="text-sm">{phone.processor}</span>
                  </div>
                  <div className="flex items-center">
                    <i className="fas fa-battery-full text-primary mr-2"></i>
                    <span className="text-sm">{phone.battery}</span>
                  </div>
                </div>
                
                <div className="border-t pt-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="text-2xl font-bold text-gray-900">{formatPrice(phone.price)}</div>
                      {phone.originalPrice && phone.originalPrice > phone.price && (
                        <div className="text-sm text-gray-500 line-through">{formatPrice(phone.originalPrice)}</div>
                      )}
                    </div>
                    <div className="text-right">
                      <div className="flex items-center">
                        <i className="fas fa-star text-yellow-400 mr-1"></i>
                        <span className="font-semibold">{phone.rating}</span>
                      </div>
                      <div className="text-sm text-gray-500">{phone.reviewCount.toLocaleString()} reviews</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="text-xs text-gray-500 font-medium mb-1">Available at:</div>
                    <div className="grid grid-cols-2 gap-2">
                      <button 
                        onClick={() => window.open(`https://amazon.in/s?k=${encodeURIComponent(phone.name)}`, '_blank')}
                        className="bg-orange-500 text-white px-3 py-2 rounded-lg text-xs font-semibold hover:bg-orange-600 transition-colors flex items-center justify-center"
                      >
                        <i className="fab fa-amazon mr-1"></i> Amazon
                      </button>
                      <button 
                        onClick={() => window.open(`https://flipkart.com/search?q=${encodeURIComponent(phone.name)}`, '_blank')}
                        className="bg-blue-500 text-white px-3 py-2 rounded-lg text-xs font-semibold hover:bg-blue-600 transition-colors flex items-center justify-center"
                      >
                        <i className="fas fa-shopping-cart mr-1"></i> Flipkart
                      </button>
                    </div>
                    <button 
                      onClick={() => document.getElementById(`price-comparison-${phone.id}`)?.scrollIntoView({ behavior: 'smooth' })}
                      className="w-full bg-primary text-white px-3 py-2 rounded-lg text-xs font-semibold hover:bg-blue-700 transition-colors"
                    >
                      Compare All Prices
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
