import { Phone } from "@shared/schema";

interface ComparisonTableProps {
  phones: Phone[];
}

export default function ComparisonTable({ phones }: ComparisonTableProps) {
  if (phones.length === 0) return null;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getBestValue = (phones: Phone[], key: keyof Phone) => {
    if (key === 'price') {
      return Math.min(...phones.map(p => p.price));
    }
    if (key === 'rating') {
      return Math.max(...phones.map(p => parseFloat(p.rating)));
    }
    return null;
  };

  const isBestValue = (phone: Phone, key: keyof Phone) => {
    const bestValue = getBestValue(phones, key);
    if (bestValue === null) return false;
    
    if (key === 'price') {
      return phone.price === bestValue;
    }
    if (key === 'rating') {
      return parseFloat(phone.rating) === bestValue;
    }
    return false;
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">Compare Specifications</h3>
          <p className="text-gray-600 text-lg">Side-by-side comparison of top recommendations</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Specification</th>
                  {phones.map((phone) => (
                    <th key={phone.id} className="px-6 py-4 text-center text-sm font-semibold text-gray-900">
                      {phone.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">Display</td>
                  {phones.map((phone) => (
                    <td key={phone.id} className="px-6 py-4 text-sm text-gray-600 text-center">
                      {phone.display}
                    </td>
                  ))}
                </tr>
                <tr className="bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">Processor</td>
                  {phones.map((phone) => (
                    <td key={phone.id} className="px-6 py-4 text-sm text-gray-600 text-center">
                      {phone.processor}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">Camera</td>
                  {phones.map((phone) => (
                    <td key={phone.id} className="px-6 py-4 text-sm text-gray-600 text-center">
                      {phone.camera}
                    </td>
                  ))}
                </tr>
                <tr className="bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">Battery</td>
                  {phones.map((phone) => (
                    <td key={phone.id} className="px-6 py-4 text-sm text-gray-600 text-center">
                      {phone.battery}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">RAM</td>
                  {phones.map((phone) => (
                    <td key={phone.id} className="px-6 py-4 text-sm text-gray-600 text-center">
                      {phone.ram}
                    </td>
                  ))}
                </tr>
                <tr className="bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">Storage</td>
                  {phones.map((phone) => (
                    <td key={phone.id} className="px-6 py-4 text-sm text-gray-600 text-center">
                      {phone.storage}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">Rating</td>
                  {phones.map((phone) => (
                    <td key={phone.id} className={`px-6 py-4 text-sm text-gray-600 text-center ${
                      isBestValue(phone, 'rating') ? 'bg-green-50 border-l-4 border-green-500' : ''
                    }`}>
                      {phone.rating}/5
                    </td>
                  ))}
                </tr>
                <tr className="bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">Price</td>
                  {phones.map((phone) => (
                    <td key={phone.id} className={`px-6 py-4 text-sm text-gray-600 text-center ${
                      isBestValue(phone, 'price') ? 'bg-green-50 border-l-4 border-green-500' : ''
                    }`}>
                      {formatPrice(phone.price)}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
