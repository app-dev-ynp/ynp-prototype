import { useQuery } from "@tanstack/react-query";
import { Phone } from "@shared/schema";
import PriceAlerts from "./price-alerts";

interface PriceComparisonProps {
  phone: Phone;
}

export default function PriceComparison({ phone }: PriceComparisonProps) {
  const { data: sellers, isLoading } = useQuery({
    queryKey: ['/api/sellers', phone.id],
    queryFn: async () => {
      const response = await fetch(`/api/sellers/${phone.id}`);
      return response.json();
    },
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getIconClass = (icon: string) => {
    const iconMap: { [key: string]: string } = {
      'amazon': 'fab fa-amazon',
      'shopping-cart': 'fas fa-shopping-cart',
      'store': 'fas fa-store',
      'mobile-alt': 'fas fa-mobile-alt',
      'apple': 'fab fa-apple',
      'google': 'fab fa-google',
    };
    return iconMap[icon] || 'fas fa-shopping-cart';
  };

  const getColorClass = (color: string) => {
    const colorMap: { [key: string]: string } = {
      'orange': 'bg-orange-500 hover:bg-orange-600',
      'blue': 'bg-blue-500 hover:bg-blue-600',
      'purple': 'bg-purple-500 hover:bg-purple-600',
      'red': 'bg-red-500 hover:bg-red-600',
      'black': 'bg-gray-800 hover:bg-gray-900',
      'gray': 'bg-gray-600 hover:bg-gray-700',
      'yellow': 'bg-yellow-500 hover:bg-yellow-600',
    };
    return colorMap[color] || 'bg-blue-500 hover:bg-blue-600';
  };

  const getBestDeal = () => {
    if (!sellers || sellers.length === 0) return null;
    return sellers.reduce((best: any, seller: any) => 
      seller.price < best.price ? seller : best
    );
  };

  const bestDeal = getBestDeal();

  if (isLoading) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Best Deals Available</h3>
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">Best Deals Available</h3>
          <p className="text-gray-600 text-lg">Compare prices across multiple sellers</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <h4 className="text-xl font-bold text-gray-900">{phone.name} - Price Comparison</h4>
          </div>
          
          <div className="p-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {sellers?.map((seller: any, index: number) => {
                const isBestPrice = bestDeal && seller.price === bestDeal.price;
                return (
                  <div 
                    key={seller.id} 
                    className={`border rounded-lg p-4 hover:shadow-md transition-all duration-300 ${
                      isBestPrice 
                        ? 'border-green-500 bg-green-50 ring-2 ring-green-200' 
                        : 'border-gray-200 hover:border-primary'
                    }`}
                  >
                    {isBestPrice && (
                      <div className="flex items-center mb-2">
                        <i className="fas fa-trophy text-green-600 mr-2"></i>
                        <span className="text-sm font-semibold text-green-700">Best Price</span>
                      </div>
                    )}
                    
                    <div className="flex items-center mb-3">
                      <i className={`${getIconClass(seller.icon)} text-2xl mr-3`} style={{ color: seller.color === 'orange' ? '#ff9500' : seller.color === 'blue' ? '#1877f2' : seller.color === 'black' ? '#000' : seller.color === 'gray' ? '#666' : seller.color === 'red' ? '#dc3545' : seller.color === 'yellow' ? '#ffc107' : '#6c757d' }}></i>
                      <div>
                        <div className="font-semibold text-gray-900">{seller.name}</div>
                        <div className="text-sm text-gray-600">
                          {seller.features && seller.features.length > 0 ? seller.features.join(', ') : 'Available'}
                        </div>
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <div className="flex items-baseline justify-between mb-1">
                        <div className="text-2xl font-bold text-gray-900">{formatPrice(seller.price)}</div>
                        {seller.discount > 0 && (
                          <span className="bg-red-100 text-red-800 text-xs font-semibold px-2 py-1 rounded">
                            {seller.discount}% OFF
                          </span>
                        )}
                      </div>
                      
                      {seller.originalPrice && seller.originalPrice > seller.price && (
                        <>
                          <div className="text-sm text-gray-500 line-through">{formatPrice(seller.originalPrice)}</div>
                          <div className="text-sm text-green-600 font-semibold">
                            You save {formatPrice(seller.originalPrice - seller.price)}
                          </div>
                        </>
                      )}
                      
                      {bestDeal && seller.price !== bestDeal.price && (
                        <div className="text-sm text-orange-600 mt-1">
                          +{formatPrice(seller.price - bestDeal.price)} more than best price
                        </div>
                      )}
                    </div>
                    
                    <button 
                      onClick={() => window.open(seller.affiliateLink, '_blank')}
                      className={`w-full ${getColorClass(seller.color)} text-white px-4 py-2 rounded-lg font-semibold transition-colors flex items-center justify-center`}
                    >
                      <i className={`${getIconClass(seller.icon)} mr-2`}></i>
                      Buy Now
                    </button>
                    
                    <div className="mt-2 text-center">
                      <button className="text-sm text-primary hover:underline">
                        Set Price Alert
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
            
            {/* Price Summary and Savings */}
            {sellers && sellers.length > 0 && (
              <div className="mt-6 space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  {/* Price Summary */}
                  <div className="bg-gradient-to-r from-green-50 to-green-100 p-4 rounded-lg border border-green-200">
                    <div className="flex items-center mb-2">
                      <i className="fas fa-chart-line text-green-600 mr-2"></i>
                      <h5 className="font-semibold text-green-800">Price Summary</h5>
                    </div>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span className="text-green-700">Lowest Price:</span>
                        <span className="font-semibold text-green-800">{formatPrice(Math.min(...sellers.map((s: any) => s.price)))}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-green-700">Highest Price:</span>
                        <span className="font-semibold text-green-800">{formatPrice(Math.max(...sellers.map((s: any) => s.price)))}</span>
                      </div>
                      <div className="flex justify-between border-t border-green-300 pt-1">
                        <span className="text-green-700">Max Savings:</span>
                        <span className="font-bold text-green-800">{formatPrice(Math.max(...sellers.map((s: any) => s.price)) - Math.min(...sellers.map((s: any) => s.price)))}</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Price Alert */}
                  <PriceAlerts phone={phone} />
                </div>

                {bestDeal && (
                  <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                    <div className="flex items-center">
                      <i className="fas fa-trophy text-green-600 mr-3"></i>
                      <div>
                        <div className="font-semibold text-green-800">
                          Best Deal: {bestDeal.name} at {formatPrice(bestDeal.price)}
                        </div>
                        <div className="text-sm text-green-700">
                          Save up to {formatPrice(Math.max(...sellers.map((s: any) => s.price)) - bestDeal.price)} compared to highest price
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
