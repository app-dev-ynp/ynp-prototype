import { useQuery } from "@tanstack/react-query";
import { Phone } from "@shared/schema";

interface YoutubeReviewsProps {
  phones: Phone[];
}

export default function YoutubeReviews({ phones }: YoutubeReviewsProps) {
  const { data: reviews, isLoading } = useQuery({
    queryKey: ['/api/reviews', phones[0]?.id],
    queryFn: async () => {
      if (!phones[0]) return [];
      const response = await fetch(`/api/reviews/${phones[0].id}`);
      return response.json();
    },
    enabled: phones.length > 0,
  });

  if (isLoading) {
    return (
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Expert Reviews</h3>
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          </div>
        </div>
      </section>
    );
  }

  const handlePlayVideo = (videoId: string) => {
    // In a real implementation, this would open a YouTube video player
    window.open(`https://www.youtube.com/watch?v=${videoId}`, '_blank');
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">Expert Reviews</h3>
          <p className="text-gray-600 text-lg">Watch detailed reviews from trusted tech channels</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews?.map((review: any) => (
            <div key={review.id} className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="relative">
                <img 
                  src={review.thumbnail} 
                  alt={review.title} 
                  className="w-full h-48 object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                  <button
                    onClick={() => handlePlayVideo(review.videoId)}
                    className="bg-red-600 text-white px-4 py-2 rounded-full flex items-center hover:bg-red-700 transition-colors"
                  >
                    <i className="fab fa-youtube mr-2"></i>
                    <span className="font-semibold">Play Review</span>
                  </button>
                </div>
              </div>
              <div className="p-6">
                <h4 className="font-bold text-lg mb-2">{review.channel}</h4>
                <p className="text-gray-600 mb-4">{review.title}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <i className="fas fa-eye text-gray-500 mr-2"></i>
                    <span className="text-sm text-gray-600">{review.views} views</span>
                  </div>
                  <div className="flex items-center">
                    <i className="fas fa-thumbs-up text-green-500 mr-2"></i>
                    <span className="text-sm text-gray-600">{review.likePercentage}% liked</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          {/* Fallback reviews if no data */}
          {(!reviews || reviews.length === 0) && (
            <>
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="relative">
                  <img 
                    src="https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300" 
                    alt="YouTube tech review interface" 
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                    <div className="bg-red-600 text-white px-4 py-2 rounded-full flex items-center">
                      <i className="fab fa-youtube mr-2"></i>
                      <span className="font-semibold">Play Review</span>
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <h4 className="font-bold text-lg mb-2">Technical Guruji</h4>
                  <p className="text-gray-600 mb-4">Complete Review - Worth Buying?</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className="fas fa-eye text-gray-500 mr-2"></i>
                      <span className="text-sm text-gray-600">2.3M views</span>
                    </div>
                    <div className="flex items-center">
                      <i className="fas fa-thumbs-up text-green-500 mr-2"></i>
                      <span className="text-sm text-gray-600">95% liked</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="relative">
                  <img 
                    src="https://pixabay.com/get/g6b3796e8b8626b1bdc30ba7f324786e444f97e2a3cad5ef053d04b450fc2a7d2add0858b5cb5685cab968c13434e4ff75725b49c32e2319e3fe893fa8acaa6d8_1280.jpg" 
                    alt="Phone comparison review interface" 
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                    <div className="bg-red-600 text-white px-4 py-2 rounded-full flex items-center">
                      <i className="fab fa-youtube mr-2"></i>
                      <span className="font-semibold">Play Review</span>
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <h4 className="font-bold text-lg mb-2">Geeky Ranjit</h4>
                  <p className="text-gray-600 mb-4">Detailed Comparison - Which to Buy?</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className="fas fa-eye text-gray-500 mr-2"></i>
                      <span className="text-sm text-gray-600">1.8M views</span>
                    </div>
                    <div className="flex items-center">
                      <i className="fas fa-thumbs-up text-green-500 mr-2"></i>
                      <span className="text-sm text-gray-600">92% liked</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="relative">
                  <img 
                    src="https://pixabay.com/get/g68928c1afa085b2583daebf3153b865d09ae7be5d4dce0fb6cf977fdc4a63dbe3fb59b9fbc6a23c1a448955ffc52db9a245f3b3fc55599f3a14b24e0dbe0ce91_1280.jpg" 
                    alt="Phone testing review interface" 
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                    <div className="bg-red-600 text-white px-4 py-2 rounded-full flex items-center">
                      <i className="fab fa-youtube mr-2"></i>
                      <span className="font-semibold">Play Review</span>
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <h4 className="font-bold text-lg mb-2">Trakin Tech</h4>
                  <p className="text-gray-600 mb-4">Full Review - Gaming Beast at Best Price!</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className="fas fa-eye text-gray-500 mr-2"></i>
                      <span className="text-sm text-gray-600">956K views</span>
                    </div>
                    <div className="flex items-center">
                      <i className="fas fa-thumbs-up text-green-500 mr-2"></i>
                      <span className="text-sm text-gray-600">96% liked</span>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
