import { useState } from "react";
import { Phone } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface PriceAlertsProps {
  phone: Phone;
}

export default function PriceAlerts({ phone }: PriceAlertsProps) {
  const [email, setEmail] = useState("");
  const [targetPrice, setTargetPrice] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const { toast } = useToast();

  const handlePriceAlert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !targetPrice) return;

    // In a real app, this would make an API call to set up price alerts
    setIsSubscribed(true);
    toast({
      title: "Price Alert Set!",
      description: `We'll notify you when ${phone.name} drops to ₹${targetPrice} or below.`,
    });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  if (isSubscribed) {
    return (
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-center">
          <i className="fas fa-bell text-green-600 mr-3"></i>
          <div>
            <div className="font-semibold text-green-800">Price Alert Active</div>
            <div className="text-sm text-green-700">
              You'll be notified when the price drops to {formatPrice(parseInt(targetPrice))} or below.
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
      <div className="flex items-center mb-3">
        <i className="fas fa-bell text-blue-600 mr-2"></i>
        <h4 className="font-semibold text-blue-800">Set Price Alert</h4>
      </div>
      <p className="text-sm text-blue-700 mb-4">
        Get notified when the price drops below your target price.
      </p>
      
      <form onSubmit={handlePriceAlert} className="space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Email Address
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="your@email.com"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Target Price (₹)
          </label>
          <input
            type="number"
            value={targetPrice}
            onChange={(e) => setTargetPrice(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="50000"
            min="1"
            max={phone.price - 1000}
            required
          />
        </div>
        <button
          type="submit"
          className="w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors font-semibold"
        >
          Set Alert
        </button>
      </form>
      
      <div className="mt-3 text-xs text-gray-600">
        Current lowest price: {formatPrice(phone.price)}
      </div>
    </div>
  );
}